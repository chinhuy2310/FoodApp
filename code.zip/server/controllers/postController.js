const connection = require('../config/db');
const fs = require('fs');
  exports.createPost = (req, res) => {
    const { post_title, post_content, isRecipe, user_id, post_group } = req.body;
    const imageUrls = req.files.map(file => `http://192.168.86.182:3000/uploads/${file.filename}`);

    const query = 'INSERT INTO posts (category, is_recipe, user_id, title, content) VALUES (?, ?, ?, ?, ?)';
    connection.query(query, [post_group, isRecipe, user_id, post_title, post_content], (error, results) => {
      if (error) {
        console.error('Error creating post:', error);
        return res.status(500).json({ error: 'Internal server error' });
      }

      const post_id = results.insertId;
      imageUrls.forEach(imageUrl => {
        connection.query('INSERT INTO images (post_id, path) VALUES (?, ?)', [post_id, imageUrl], (error) => {
          if (error) {
            console.error('Error saving post images:', error);
            return res.status(500).json({ error: 'Internal server error' });
          }
        });
      });

      res.status(201).json({ message: 'Post created successfully' });
    });
  };

  exports.deletePost = (req, res) => {
    const postId = req.params.postId;
  
    connection.query('SELECT * FROM images WHERE post_id = ?', [postId], (selectImagesErr, selectImagesResults) => {
      if (selectImagesErr) {
        console.error('Error retrieving images:', selectImagesErr);
        return res.status(500).json({ error: 'Internal server error' });
      }
  
      const imagePaths = selectImagesResults.map(image => image.path);
  
     // Xóa hình ảnh từ thư mục uploads
    imagePaths.forEach(imagePath => {
      const filename = imagePath.split('/').pop(); // Lấy tên tệp từ đường dẫn
      fs.unlink(`uploads/${filename}`, (unlinkErr) => {
        if (unlinkErr) {
          // Nếu không tìm thấy tệp trong uploads, tiếp tục xóa bài viết
          if (unlinkErr.code === 'ENOENT') {
            console.error('File not found in uploads:', unlinkErr);
          } else {
            console.error('Error deleting image file:', unlinkErr);
            return res.status(500).json({ error: 'Internal server error' });
          }
        }
      });
    });
  
      // Kiểm tra sự tồn tại của bài viết trước khi tiếp tục
      connection.query('SELECT * FROM posts WHERE post_id = ?', [postId], (selectErr, selectResults) => {
        if (selectErr) {
          console.error('Error checking post existence:', selectErr);
          return res.status(500).json({ error: 'Internal server error' });
        }
  
        if (selectResults.length === 0) {
          return res.status(404).json({ error: 'Post not found' });
        }
  
        // Tiếp tục với việc xóa dữ liệu từ các bảng khác và commit transaction
        connection.beginTransaction((beginTransactionErr) => {
          if (beginTransactionErr) {
            console.error('Error starting transaction:', beginTransactionErr);
            return res.status(500).json({ error: 'Internal server error' });
          }
  
          connection.query('DELETE FROM comments WHERE post_id = ?', [postId], (deleteCommentsErr) => {
            if (deleteCommentsErr) {
              connection.rollback(() => {
                console.error('Error deleting post comments:', deleteCommentsErr);
                return res.status(500).json({ error: 'Internal server error' });
              });
            }
  
            connection.query('DELETE FROM likes WHERE post_id = ?', [postId], (deleteLikesErr) => {
              if (deleteLikesErr) {
                connection.rollback(() => {
                  console.error('Error deleting post likes:', deleteLikesErr);
                  return res.status(500).json({ error: 'Internal server error' });
                });
              }
  
              connection.query('DELETE FROM posts WHERE post_id = ?', [postId], (deletePostErr) => {
                if (deletePostErr) {
                  connection.rollback(() => {
                    console.error('Error deleting post:', deletePostErr);
                    return res.status(500).json({ error: 'Internal server error' });
                  });
                }
  
                connection.commit((commitErr) => {
                  if (commitErr) {
                    connection.rollback(() => {
                      console.error('Error committing transaction:', commitErr);
                      return res.status(500).json({ error: 'Internal server error' });
                    });
                  }
  
                  res.status(200).json({ message: 'Post and related data deleted successfully' });
                });
              });
            });
          });
        });
      });
    });
  };
  

exports.getPostById = (req, res) => {
  const post_id = req.query.post_id;
  const userId = req.query.user_id;
  const query = `
  SELECT 
  users.avatar_image,
  posts.*,
  users.name,
  GROUP_CONCAT(DISTINCT images.path ORDER BY images.image_id) AS imageUrls,
  COUNT(DISTINCT likes.like_id) AS likeCount,
  (SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
   FROM likes 
   WHERE likes.post_id = posts.post_id AND likes.user_id = ?) AS isLiked,
  COUNT(DISTINCT comments.comment_id) AS commentCount
  FROM 
    posts 
  JOIN 
    users  ON posts.user_id = users.user_id
  LEFT JOIN 
    images ON posts.post_id = images.post_id
  LEFT JOIN 
    likes ON posts.post_id = likes.post_id
  LEFT JOIN 
    comments ON posts.post_id = comments.post_id
  WHERE 
    posts.post_id = ?
  GROUP BY 
    posts.post_id, users.avatar_image, users.name
  ORDER BY 
    posts.created_at DESC;

`;
  connection.query(query, [userId, post_id], (err, results) => {
    if (err) {
      console.error('Error retrieving post:', err.stack);
      return res.status(500).json({ error: 'Internal server error' });
    }
    if (results.length === 0) {
      return res.status(404).json({ error: 'Post not found' });
    }
    const post = results[0];
    res.status(200).json(post);
  });
};

exports.getPostByUser = (req, res) => {
  const userId = req.query.user_id;

  const query = `
  SELECT 
      users.avatar_image,
      posts.*,
      users.name,
      GROUP_CONCAT(DISTINCT images.path ORDER BY images.image_id) AS imageUrls,
      COUNT(DISTINCT likes.like_id) AS likeCount,
      (SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
       FROM likes 
       WHERE likes.post_id = posts.post_id AND likes.user_id = ?) AS isLiked,
      COUNT(DISTINCT comments.comment_id) AS commentCount
    FROM 
      posts 
    JOIN 
      users  ON posts.user_id = users.user_id
    LEFT JOIN 
      images ON posts.post_id = images.post_id
    LEFT JOIN 
      likes ON posts.post_id = likes.post_id
    LEFT JOIN 
      comments ON posts.post_id = comments.post_id
    WHERE 
      posts.user_id = ?
    GROUP BY 
      posts.post_id, users.avatar_image, users.name
    ORDER BY 
      posts.created_at DESC;
  `;

  connection.query(query, [userId,userId], (err, results) => {
    if (err) {
      console.error('Error retrieving posts:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }
    res.status(200).json(results);
  });
};

exports.getLikedPosts = (req, res) => {
  const userId = req.query.user_id;

  const query = `
  SELECT 
  users.avatar_image,
  posts.*,
  users.name,
  GROUP_CONCAT(DISTINCT images.path ORDER BY images.image_id) AS imageUrls,
  COUNT(DISTINCT likes.like_id) AS likeCount,
  (SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
      FROM likes 
      WHERE likes.post_id = posts.post_id AND likes.user_id = ?) AS isLiked,
  COUNT(DISTINCT comments.comment_id) AS commentCount
FROM 
  posts 
JOIN 
  users  ON posts.user_id = users.user_id
LEFT JOIN 
  images ON posts.post_id = images.post_id
LEFT JOIN 
  likes ON posts.post_id = likes.post_id
LEFT JOIN 
  comments ON posts.post_id = comments.post_id
GROUP BY 
  posts.post_id, users.avatar_image, users.name
HAVING 
  isLiked = 1
  AND posts.user_id != ?
ORDER BY 
  posts.created_at DESC;
  `;

  connection.query(query, [userId,userId], (err, results) => {
    if (err) {
      console.error('Error retrieving posts:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }
    res.status(200).json(results);
  });
};



exports.getAllPosts = (req, res) => {
  const userId = req.query.user_id;

  const query = `
  SELECT 
      users.avatar_image,
      posts.*,
      users.name,
      GROUP_CONCAT(DISTINCT images.path ORDER BY images.image_id) AS imageUrls,
      COUNT(DISTINCT likes.like_id) AS likeCount,
      (SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
       FROM likes 
       WHERE likes.post_id = posts.post_id AND likes.user_id = ?) AS isLiked,
      COUNT(DISTINCT comments.comment_id) AS commentCount
    FROM 
      posts 
    JOIN 
      users  ON posts.user_id = users.user_id
    LEFT JOIN 
      images ON posts.post_id = images.post_id
    LEFT JOIN 
      likes ON posts.post_id = likes.post_id
    LEFT JOIN 
      comments ON posts.post_id = comments.post_id
    GROUP BY 
      posts.post_id, users.avatar_image, users.name
    ORDER BY 
      posts.created_at DESC;
  `;

  connection.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error retrieving posts:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }
    res.status(200).json(results);
  });
};




exports.getPopularPosts = (req, res) => {
  const userId = req.query.user_id;
  let daysInterval = 30;

  const getPopularPosts = (days) => {
    const query = `
      SELECT 
        users.avatar_image,
        posts.*,
        users.name,
        GROUP_CONCAT(DISTINCT images.path ORDER BY images.image_id) AS imageUrls,
        COUNT(DISTINCT likes.like_id) AS likeCount,
        (SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
         FROM likes 
         WHERE likes.post_id = posts.post_id AND likes.user_id = ?) AS isLiked,
        COUNT(DISTINCT comments.comment_id) AS commentCount
      FROM 
        posts 
      JOIN 
        users  ON posts.user_id = users.user_id
      LEFT JOIN 
        images ON posts.post_id = images.post_id
      LEFT JOIN 
        likes ON posts.post_id = likes.post_id
      LEFT JOIN 
        comments ON posts.post_id = comments.post_id
      WHERE 
        posts.created_at >= DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL ? DAY)
      GROUP BY 
        posts.post_id
      ORDER BY 
        likeCount DESC
      LIMIT 5;
    `;

    connection.query(query, [userId, days], (err, results) => {
      if (err) {
        console.error('Error retrieving popular posts:', err);
        return res.status(500).json({ error: 'Internal server error' });
      }

      if (results.length < 5 && days < 365) {
        getPopularPosts(days + 30);
      } else {
        res.status(200).json(results);
      }
    });
  };

  getPopularPosts(daysInterval);
};

exports.getAdvertisements = (req, res) => {
  const query = 'SELECT * FROM advertisement;';
  connection.query(query, (err, results) => {
      if (err) throw err;
      const imageUrls = results.map(row => row.advertisement_image);
      res.json({ advertisement: imageUrls });
  });
};