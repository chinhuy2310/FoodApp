package com.example.servertest;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.servertest.adapter.adapterPostMenu1;
import com.example.servertest.model.Post;
import com.example.servertest.model.User;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Menu3Fragment extends Fragment {
    private RecyclerView recyclerView;
    private adapterPostMenu1 adapter;
    private List<Post> postList;
    private int groupID;
    private TextView emptyView, textView3;
    private EditText searchEditText;
    private ImageView searchButton, filterButton, searchButtonL;
    private HorizontalScrollView horizontalScrollView;
    private String searchText = "";
    private View childView;
    private User user;
    private APIService apiService;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.menu3fragment, container, false);

        // Retrieve user data from Bundle
        Bundle bundle = getArguments();
        if (bundle != null) {
            user = (User) bundle.getSerializable("user");
        }

        // Initialize views from layout
        searchButtonL = view.findViewById(R.id.search_button_left);
        horizontalScrollView = view.findViewById(R.id.horizontalScrollView);
        textView3 = view.findViewById(R.id.textview3);
        emptyView = view.findViewById(R.id.emptyView);
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        postList = new ArrayList<>();
        adapter = new adapterPostMenu1(getActivity(), postList, new MyOnPostClickListener());
        recyclerView.setAdapter(adapter);
        apiService = RetrofitClientInstance.getRetrofitInstance().create(APIService.class);

        // Listen for page change in ViewPager2
        ViewPager2 viewPager2 = getActivity().findViewById(R.id.viewPager);
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                if (position == 2) {
                    // If Fragment 3 is displayed, reset data
                    resetData();
                }
            }
        });

        // Listen for item click in filter bar
        View.OnClickListener itemClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchEditText.clearFocus();
                // Get group ID of selected item
                int groupId = (int) v.getTag();
                // Perform operations corresponding to data type
                fetchDataFromApi(groupId, searchText);
                LinearLayout linearLayout = view.findViewById(R.id.filterLayout);
                // Set selected state for clicked TextView and deselect others
                for (int i = 0; i < linearLayout.getChildCount(); i++) {
                    childView = linearLayout.getChildAt(i);
                    if (childView == v) {
                        // Selected TextView
                        childView.setSelected(true);
                        Log.e("groupid", String.valueOf(groupId));
                    } else {
                        // Other TextViews
                        childView.setSelected(false);
                    }
                }
            }
        };

        // Listen for search button click
        searchButton = view.findViewById(R.id.search_button);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search();
                hideKeyboard();
            }
        });

        // Listen for filter button click
        filterButton = view.findViewById(R.id.filterButton);
        filterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "The function has not been updated yet", Toast.LENGTH_SHORT).show();
                // Open dialog when filter button is clicked
//                FilterDialogFragment dialogFragment = new FilterDialogFragment();
//                dialogFragment.show(getChildFragmentManager(), "FilterDialog");
            }
        });

        // Attach click listener and group ID to each TextView in horizontal scroll bar
        LinearLayout linearLayout = view.findViewById(R.id.filterLayout);
        for (int i = 0; i < linearLayout.getChildCount(); i++) {
            View childView = linearLayout.getChildAt(i);
            childView.setTag(getGroupIdForPosition(i)); // Set group ID for each item
            childView.setOnClickListener(itemClickListener);
        }

        // Listen for text change in search EditText
        searchEditText = view.findViewById(R.id.search_editText);
        searchEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                    search();
                    hideKeyboard();
                    return true;
                }
                return false;
            }
        });

        // Listen for text change in search EditText
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // Handle after text change
                if (editable.length() > 0) {
                    // If text is entered, hide search button
                    searchButton.setVisibility(View.VISIBLE);
                    filterButton.setVisibility(View.GONE);
                    textView3.setVisibility(View.VISIBLE);
                    horizontalScrollView.setVisibility(View.GONE);
                    searchButtonL.setVisibility(View.GONE);
                } else {
                    horizontalScrollView.setVisibility(View.GONE);
                    textView3.setVisibility(View.VISIBLE);
                }
            }
        });

        // Return the user interface view
        return view;
    }

    // Method to perform search
    public void search() {
        searchText = searchEditText.getText().toString();
        fetchDataFromApi(groupID, searchText);
        filterButton.setVisibility(View.VISIBLE);
        searchButton.setVisibility(View.GONE);
        searchButtonL.setVisibility(View.VISIBLE);
        horizontalScrollView.setVisibility(View.VISIBLE);
        textView3.setVisibility(View.GONE);
        searchEditText.clearFocus();
    }

    // Method to reset data when switching to another page in ViewPager2
    private void resetData() {
        // Clear EditText content and reset necessary data here
        if (searchEditText != null) {
            searchEditText.setText("");
        }
        filterButton.setVisibility(View.GONE);
        searchButtonL.setVisibility(View.GONE);
        groupID = 0;
        LinearLayout linearLayout = getView().findViewById(R.id.filterLayout);
        linearLayout.getChildAt(0).setSelected(true);
        for (int i = 1; i < linearLayout.getChildCount(); i++) {
            View childView = linearLayout.getChildAt(i);
            childView.setSelected(false);
        }
    }

    // Method to get group ID for each position in horizontal scroll bar
    private int getGroupIdForPosition(int position) {
        if (position == 0) {
            return 0; // All item
        } else {
            return position; // Other items
        }
    }

    // Method to update empty view visibility when post list is empty
    private void updateEmptyViewVisibility() {
        if (postList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);
        }
    }

    // Method to fetch data from API
    public void fetchDataFromApi(int groupId, String searchText) {
        this.groupID = groupId;
        Call<List<Post>> call = apiService.getSearch(groupId, searchText);
        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                if (response.isSuccessful()) {
                    List<Post> posts = response.body();
                    postList.clear();
                    if (posts != null) {
                        postList.addAll(posts);
                    }
                    adapter.notifyDataSetChanged();
                    updateEmptyViewVisibility();
                } else {
                    Toast.makeText(getActivity(), "Failed to fetch data from API", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                Log.e("Menu3Fragment", "Failed to fetch data: " + t.getMessage());
                Toast.makeText(getActivity(), "Failed to fetch data from API", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Listener class for post click event
    private class MyOnPostClickListener implements adapterPostMenu1.OnPostClickListener {
        @Override
        public void onPostClick(int position) {
            Post clickedPost = postList.get(position);
            int postId = clickedPost.getPostId();
            // Send Intent to PostDetail Activity and attach Post object
            Intent intent = new Intent(getActivity(), PostDetail.class);
            intent.putExtra("POST_DETAIL", clickedPost);
            intent.putExtra("POST_ID", postId);
            intent.putExtra("user", user);
            startActivity(intent);
        }
    }

    // Method to hide soft keyboard
    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
    }
}
