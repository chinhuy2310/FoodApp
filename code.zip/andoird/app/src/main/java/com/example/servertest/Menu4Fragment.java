package com.example.servertest;

import androidx.fragment.app.Fragment;

public class Menu4Fragment extends Fragment {
}
