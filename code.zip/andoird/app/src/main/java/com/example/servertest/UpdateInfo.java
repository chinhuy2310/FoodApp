package com.example.servertest;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.servertest.model.CircleTransform;
import com.example.servertest.model.User;
import com.squareup.picasso.Picasso;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateInfo extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 101;
    private static final int REQUEST_IMAGE_PICK = 102;

    private EditText usernameEditText,emailEditText;
    private ImageView imgviewMyAvt;
    private Button changeAvt,confirmButton;
    private User user;
    private Uri uri;
    private APIService apiService;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_profile);

        // ánh xạ
        usernameEditText = findViewById(R.id.editUsername);
        emailEditText = findViewById(R.id.editEmail);
        confirmButton = findViewById(R.id.send);
        changeAvt = findViewById(R.id.changeAvt);
        imgviewMyAvt = findViewById(R.id.imageViewMyAvt);


        apiService = RetrofitClientInstance.getRetrofitInstance().create(APIService.class);

        // nhận thông tin
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            user = (User) bundle.getSerializable("user");
            Log.e("user", String.valueOf(user.getUserId()));
        } else {
            Log.e("user", "null");
        }
        // thiết lập hiển thị thông tin
        if (user != null) {
            usernameEditText.setText(user.getUsername());
            emailEditText.setText(user.getEmail());
            if (user.getAvatarImage() != null && !user.getAvatarImage().isEmpty()) {
                Picasso.get().load(user.getAvatarImage())
                        .transform(new CircleTransform())
                        .placeholder(R.drawable.custom_border2)
                        .error(R.drawable.custom_border2)
                        .into(imgviewMyAvt);
            } else {
                imgviewMyAvt.setImageResource(R.drawable.user_icon2);
            }
        }

        changeAvt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Kiểm tra quyền truy cập vào bộ nhớ
                if (ContextCompat.checkSelfPermission(UpdateInfo.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    // Yêu cầu quyền truy cập
                    ActivityCompat.requestPermissions(UpdateInfo.this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            REQUEST_IMAGE_PICK);
                } else {
                    // Mở intent để chọn hoặc chụp ảnh
                    openImagePicker();
                }
            }
        });

        // khi nhấn vào nút xác nhận
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameEditText.getText().toString();
                String email = emailEditText.getText().toString();
                //call API here
                updateUserInfo();

            }
        });
        //thiết lâph nút back
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        }
    }
    // Phương thức để mở intent để chọn hoặc chụp ảnh
    private void openImagePicker() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), REQUEST_IMAGE_PICK);
    }

    // Xử lý kết quả trả về từ Intent chọn ảnh
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            uri = data.getData(); // Update uri variable
            Picasso.get().load(uri)
                    .transform(new CircleTransform())
                    .placeholder(R.drawable.custom_border2)
                    .error(R.drawable.custom_border2)
                    .into(imgviewMyAvt);
        }
    }

    // Xử lý kết quả khi người dùng đã cho phép hoặc từ chối quyền truy cập
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_IMAGE_PICK) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Nếu người dùng đã cho phép, mở intent để chọn hoặc chụp ảnh
                openImagePicker();
            } else {
                // Nếu người dùng từ chối, hiển thị thông báo
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
    // Cập nhật thông tin người dùng lên máy chủ
    private void updateUserInfo() {
        String username = usernameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        int userId = user.getUserId();
        Log.e("data",username+"  email: "+email);

        // Chuẩn bị dữ liệu cần gửi
        RequestBody usernameBody = RequestBody.create(MediaType.parse("text/plain"), username);
        RequestBody emailBody = RequestBody.create(MediaType.parse("text/plain"), email);
        // Kiểm tra xem có ảnh đại diện mới không
        MultipartBody.Part avatarImagePart = null;
        if (uri != null) {
            File file = new File(getRealPathFromURI(uri));
            RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
            avatarImagePart = MultipartBody.Part.createFormData("avatar_image", file.getName(), requestFile);
        }

        // Gọi API để cập nhật thông tin người dùng
        Call<ResponseBody> call = apiService.updateUserWithImage(userId, usernameBody, emailBody, avatarImagePart);

        // Thực hiện yêu cầu
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    // Xử lý khi cập nhật thành công
                    Toast.makeText(UpdateInfo.this, "Update successful", Toast.LENGTH_SHORT).show();
//                    LoginActivity loginactivity = new LoginActivity();
//                    loginactivity.getUserInfo(username);
                } else {
                    // Xử lý khi cập nhật thất bại
                    Toast.makeText(UpdateInfo.this, "Update failed", Toast.LENGTH_SHORT).show();
                    Log.e("response failed", String.valueOf(response.code()));
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                // Xử lý khi gặp lỗi kết nối hoặc lỗi khác
                Toast.makeText(UpdateInfo.this, "Update failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    // Phương thức này để lấy đường dẫn thực từ Uri
    private String getRealPathFromURI(Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String path = cursor.getString(column_index);
        cursor.close();
        return path;
    }
    // sự kiện khi nhấn nút back
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Go back to previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}