package com.example.servertest;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servertest.adapter.CommentAdapter;
import com.example.servertest.adapter.PostImageAdapter;
import com.example.servertest.model.Comment;
import com.example.servertest.model.Post;
import com.example.servertest.model.User;
import com.squareup.picasso.Picasso;

import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PostDetail extends AppCompatActivity {
    // UI components
    private NestedScrollView netscrollview;
    private ImageButton buttonLike, buttonComment;
    private ImageView imageViewAvatar, sendComment, postOptions;
    private TextView textViewUsername, textViewDateTime, textViewTitle, textViewContent, txtRecipe, likeCountTextView, commentCountTextView;
    private RecyclerView recyclerViewImages, recyclerViewComments;
    private EditText writecomment;

    // API service and data
    private APIService apiService;
    private User user;
    private Post post;
    private int postId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_detail);

        // Retrieve logged-in user information
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("user")) {
            user = (User) intent.getSerializableExtra("user");
        }else {

        }

        // Retrieve post information from previous activity
        post = (Post) getIntent().getSerializableExtra("POST_DETAIL");
        postId = intent.getIntExtra("POST_ID", -1);
        int userId = user.getUserId();

        // Initialize UI components
        imageViewAvatar = findViewById(R.id.imageViewAvatar);
        textViewUsername = findViewById(R.id.textViewUsername);
        textViewDateTime = findViewById(R.id.textViewDateTime);
        textViewTitle = findViewById(R.id.textViewTitle);
        textViewContent = findViewById(R.id.textViewContent);
        txtRecipe = findViewById(R.id.txtRecipe);
        netscrollview = findViewById(R.id.netscrollview);
        recyclerViewImages = findViewById(R.id.recyclerViewImages);
        recyclerViewComments = findViewById(R.id.recyclerViewComments);
        writecomment = findViewById(R.id.writeComment);
        sendComment = findViewById(R.id.sendComment);
        likeCountTextView = findViewById(R.id.likeCountTextView);
        commentCountTextView = findViewById(R.id.commentCountTextView);
        buttonLike = findViewById(R.id.buttonLike);
        buttonComment = findViewById(R.id.buttonComment);
        postOptions = findViewById(R.id.options);

        // Handle options menu click
        postOptions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showOptionsMenu();
            }
        });

        // Handle like button click
        buttonLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                likePost(userId, postId);
            }
        });

        // Handle comment button click
        buttonComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                writecomment.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(writecomment, InputMethodManager.SHOW_IMPLICIT);
            }
        });

        boolean scrollToComment = getIntent().getBooleanExtra("SCROLL_TO_COMMENT", false);
        if (scrollToComment) {
            recyclerViewComments.post(new Runnable() {
                @Override
                public void run() {
                    // Cuộn RecyclerView đến phần comment
                    scrollToComments();
                    // Hiển thị bàn phím để nhập comment
                    writecomment.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(writecomment, InputMethodManager.SHOW_IMPLICIT);
                }
            });
        }

        // Handle text change in write comment EditText
        writecomment.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                // thiết lâp hiển thị
                if (s.toString().trim().isEmpty()) {
                    sendComment.setVisibility(View.GONE);
                } else {
                    sendComment.setVisibility(View.VISIBLE);
                }
            }
        });

        // Handle send comment button click
        sendComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendComment();
            }
        });

        // Show back button in ActionBar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        }

        // Display post details
        if (post != null) {
            displayPostDetails(post);
            displayComments(post.getComments());
        } else {
            // Handle null post case
        }

        // Initialize API service
        apiService = RetrofitClientInstance.getRetrofitInstance().create(APIService.class);

        // Fetch comments for the post
        getComments();

        // Fetch post details
        getPost();
    }

    // Method to handle options menu click
    private void showOptionsMenu() {
        PopupMenu popup = new PopupMenu(PostDetail.this, postOptions);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.post_options_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.menu_report:
                        Toast.makeText(PostDetail.this, "Reported", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.menu_delete:
                        deletePostConfirmation();
                        return true;
                    default:
                        return false;
                }
            }
        });
        popup.show();
    }

    // Method to send comment
    public void sendComment() {
        if (user != null) {
            String commentContent = writecomment.getText().toString().trim();
            int userId = user.getUserId();
            if (!commentContent.isEmpty()) {
                Call<Void> call = apiService.addComment(new CommentData(userId, postId, commentContent));
                call.enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if (response.isSuccessful()) {
                            Toast.makeText(PostDetail.this, "Comment added successfully", Toast.LENGTH_SHORT).show();
                            writecomment.setText("");
                            hideKeyboard();
                            writecomment.clearFocus();
                            // Refresh comments after adding new comment
                            getComments();
                            // Refresh post data
                            getPost();
                            // Scroll to the newly added comment
                            scrollToComments();
                        } else {
                            // Handle unsuccessful response
                        }
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        // Handle failure
                    }
                });
            } else {
                Toast.makeText(this, "Please enter a comment", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Handle case where logged-in user is null

        }
    }

    // Method to handle like post action
    public void likePost(int userId, int postId) {
        if (userId != -1) {
            LikeRequest likeRequest = new LikeRequest(userId, postId);
            Call<Void> call = apiService.likePost(likeRequest);
            call.enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    if (response.isSuccessful()) {
                        // Refresh post data after liking/unliking post
                        getPost();
                    } else {
                        // Handle error
                    }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    // Handle connection error
                }
            });
        } else {
            // Handle case where userId is not found
        }
    }

    // Method to confirm post deletion
    private void deletePostConfirmation() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Deletion");
        builder.setMessage("Are you sure you want to delete this post?");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Perform API request to delete the post
                deletePost();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Dismiss the dialog
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    // Method to delete a comment with confirmation
    public void deleteCommentConfirmation(int commentId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Deletion");
        builder.setMessage("Are you sure you want to delete this comment?");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Perform API request to delete the comment
                deleteComment(commentId);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Dismiss the dialog
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    // Method to delete a comment
    public void deleteComment(int commentId) {
        Call<Void> call = apiService.deleteComment(commentId);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    // Comment deleted successfully, update comments list
                    getComments();
                    // Refresh post data
                    getPost();
                    Toast.makeText(PostDetail.this, "Comment deleted", Toast.LENGTH_SHORT).show();
                } else {
                    // Handle error
                    Toast.makeText(PostDetail.this, "Failed to delete comment", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                // Handle connection error or unknown error
                Toast.makeText(PostDetail.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method to delete a post
    private void deletePost() {
        Call<Void> call = apiService.deletePost(postId);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    // Post deleted successfully, show message and finish activity
                    Toast.makeText(PostDetail.this, "Deleted", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    // Handle error during post deletion
                    Toast.makeText(PostDetail.this, "Failed to delete post", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                // Handle connection error or unknown error
                Toast.makeText(PostDetail.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method to scroll to comments
    private void scrollToComments() {
        if (recyclerViewComments != null) {
            int totalHeight = netscrollview.getChildAt(0).getHeight();
            int recyclerViewHeight = recyclerViewComments.getHeight();
            if (totalHeight > recyclerViewHeight) {
                int scrollPosition = totalHeight - recyclerViewHeight;
                netscrollview.scrollTo(0, scrollPosition);
            } else {
                netscrollview.scrollTo(0, recyclerViewComments.getTop());
            }
        }
    }

    // Method to display post details
    private void displayPostDetails(Post post) {
        // Display post details in UI components
        String avatarUrl = post.getAvatarUrl();
        if (avatarUrl != null && !avatarUrl.isEmpty()) {
            Picasso.get().load(avatarUrl).into(imageViewAvatar);
        } else {
            Picasso.get().load(R.drawable.user_icon2).into(imageViewAvatar);
        }
        textViewUsername.setText(post.getUsername());
        textViewDateTime.setText(post.getDate());
        textViewTitle.setText(post.getTitle());
        textViewContent.setText(post.getContent());
        likeCountTextView.setText(String.valueOf(post.getLikeCount()));
        commentCountTextView.setText(String.valueOf(post.getCommentCount()));
        buttonLike.setImageResource(post.getIsLiked() == 1 ? R.drawable.ic_liked : R.drawable.like);

        // Display "Recipe" label if post is a recipe
        if (post.getIsRecipe() == 1) {
            txtRecipe.setVisibility(View.VISIBLE);
        } else {
            txtRecipe.setVisibility(View.GONE);
        }

        String imageUrls = post.getImageUrls();
        if (imageUrls != null) {
            // Display post images if available
            List<String> imageUrlList = Arrays.asList(imageUrls.split(","));
            if (!imageUrlList.isEmpty()) {
                recyclerViewImages.setVisibility(View.VISIBLE);
                recyclerViewImages.setLayoutManager(new LinearLayoutManager(this));
                recyclerViewImages.setAdapter(new PostImageAdapter(this, imageUrlList));
            } else {
                recyclerViewImages.setVisibility(View.GONE);
            }
        } else {
            recyclerViewImages.setVisibility(View.GONE);
        }
    }

    // Method to display comments
    private void displayComments(List<Comment> comments) {
        // Display comments in RecyclerView
        if (comments != null && !comments.isEmpty()) {
            recyclerViewComments.setVisibility(View.VISIBLE);
            CommentAdapter adapter = new CommentAdapter(this, comments, post);
            adapter.setUser(user);
            recyclerViewComments.setAdapter(adapter);
        } else {
            recyclerViewComments.setVisibility(View.GONE);
        }
    }

    // Method to hide keyboard
    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        View view = getCurrentFocus();
        if (view != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    // Handle back button press
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Go back to previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Method to fetch comments from API
    private void getComments() {
        Call<List<Comment>> call = apiService.getComments(postId);
        call.enqueue(new Callback<List<Comment>>() {
            @Override
            public void onResponse(Call<List<Comment>> call, Response<List<Comment>> response) {
                if (response.isSuccessful()) {
                    List<Comment> comments = response.body();
                    // Display comments in UI
                    displayComments(comments);
                } else {
                    // Handle unsuccessful response
                    Toast.makeText(PostDetail.this, "Failed to fetch comments", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Comment>> call, Throwable t) {
                // Handle connection error or unknown error
                Toast.makeText(PostDetail.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method to fetch post details from API
    private void getPost() {
        int userId = (user != null) ? user.getUserId() : -1;
        Call<Post> call = apiService.getPost(postId, userId);
        call.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call, Response<Post> response) {
                if (response.isSuccessful()) {
                    Post post = response.body();
                    // Display post details in UI
                    displayPostDetails(post);
                } else {
                    //
                }
            }

            @Override
            public void onFailure(Call<Post> call, Throwable t) {
                //
            }
        });
    }
}
