package com.example.servertest;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;


public class ChangePassword  extends AppCompatActivity {


    private EditText oldPassword,newPassword,confirmNewPassword;
    private Button confirmButton;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_password);

        oldPassword = findViewById(R.id.password);
        newPassword = findViewById(R.id.editPW);
        confirmNewPassword = findViewById(R.id.editPW2);
        confirmButton = findViewById(R.id.send);

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String password = oldPassword.getText().toString();
                String newpassword = newPassword.getText().toString();
                String confirmPW = confirmNewPassword.getText().toString();
                // call API here


            }
        });
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        }
    }

    // sự kiện khi nhấn nút back
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Go back to previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}