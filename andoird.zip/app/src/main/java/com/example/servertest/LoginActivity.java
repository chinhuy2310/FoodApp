package com.example.servertest;

// Import statements for necessary Android components and Retrofit classes
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// Importing models and interfaces
import com.example.servertest.model.User;
import com.example.servertest.model.UserResponse;

// Retrofit-related imports
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

// Defining LoginActivity class which extends AppCompatActivity
public class LoginActivity extends AppCompatActivity {

    // Declaration of variables
    private APIService apiService; // Interface for API calls
    TextView signUpTextView, findPassword, buttonLogin; // TextViews for sign-up, finding password, and login button
    EditText editTextUserAccname, editTextPassword; // EditText fields for username and password

    // Method called when LoginActivity is created
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the layout for the activity
        setContentView(R.layout.login);

        // Initializing EditText and TextView objects
        editTextUserAccname = findViewById(R.id.editTextAccount); // Username field
        editTextPassword = findViewById(R.id.editTextPasword); // Password field
        buttonLogin = findViewById(R.id.loginbutton); // Login button
        signUpTextView = findViewById(R.id.signUpTextView); // Sign-up text
        findPassword = findViewById(R.id.findPasswordText); // Password recovery text
        findPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LoginActivity.this,"this feature has not been updated yet",Toast.LENGTH_SHORT);
            }
        });
        // Set up Retrofit for making network requests
        apiService = RetrofitClientInstance.getRetrofitInstance().create(APIService.class);

        // Define the behavior when the login button is clicked
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login(); // Call the login method
            }
        });

        // Define the behavior when the sign-up text is clicked
        signUpTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the sign-up activity
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });

        // Define behavior when Enter key is pressed in password EditText
        editTextPassword.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE || (event != null && event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    buttonLogin.performClick(); // Perform login action
                    return true;
                }
                return false;
            }
        });

        // Hide the action bar if it exists
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }

    // Method to handle login action
    private void Login() {
        String useraccname = editTextUserAccname.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // Check if username and password are not empty
        if (!useraccname.isEmpty() && !password.isEmpty()) {
            // Create a login request object
            LoginRequest loginRequest = new LoginRequest(useraccname, password);

            // Make an asynchronous network call to login API
            Call<User> call = apiService.login(loginRequest);
            call.enqueue(new Callback<User>() {
                @Override
                public void onResponse(Call<User> call, Response<User> response) {
                    if (response.isSuccessful()) {
                        // If login is successful, fetch user info
                        getUserInfo(useraccname);
                    } else {
                        // Handle unsuccessful login response
//                        Log.e("LoginActivity", "Response code: " + response.code());
                    }
                }

                @Override
                public void onFailure(Call<User> call, Throwable t) {
                    // Handle network connection failure
                    Toast.makeText(LoginActivity.this, "Login failed: Cannot connect to server" + t.getMessage(), Toast.LENGTH_SHORT).show();
//                    Log.e("err","Login failed: Cannot connect to server" + t.getMessage());
                }
            });
        } else {
            // Show a toast message if username or password is empty
            Toast.makeText(LoginActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to fetch user information after successful login
    private void getUserInfo(String useraccname) {
        // Make an asynchronous network call to get user info
        Call<UserResponse> call = apiService.getUser(useraccname);
        call.enqueue(new Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                if (response.isSuccessful()) {
                    // Handle successful response and extract user information
                    UserResponse userResponse = response.body();
                    if (userResponse != null && userResponse.getUser() != null) {
                        User user = userResponse.getUser();
//                        Log.e("LoginActivity", "User: " + user.toString());
                        // Start MainActivity with user data
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        intent.putExtra("user", user);
                        startActivity(intent);
                    } else {
                        // Handle null user object in response
//                        Log.e("LoginActivity", "User object is null");
                    }
                } else {
                    // Handle unsuccessful response from getUser API
//                    Log.e("Getuser", "Response code: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<UserResponse> call, Throwable t) {
                // Handle network connection failure when fetching user info
                Toast.makeText(LoginActivity.this, "Login failed: Cannot connect to server" + t.getMessage(), Toast.LENGTH_SHORT).show();
//                Log.e("err", "getuser: Cannot connect to server" + t.getMessage());
            }
        });
    }
}
