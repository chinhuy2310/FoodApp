package com.example.servertest;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servertest.adapter.adapterPostMenu2;
import com.example.servertest.model.CircleTransform;
import com.example.servertest.model.Post;
import com.example.servertest.model.User;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Menu2Fragment extends Fragment implements adapterPostMenu2.OnPostClickListener {

    private RecyclerView recyclerView;
    private adapterPostMenu2 adapter;
    private List<Post> postList;
    private User user;
    private APIService apiService;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // 이 프래그먼트의 레이아웃을 인플레이트합니다.
        View view = inflater.inflate(R.layout.menu2fragment, container, false);

        // RetrofitClientInstance를 사용하여 APIService를 초기화합니다.
        apiService = RetrofitClientInstance.getRetrofitInstance().create(APIService.class);

        // 번들에서 사용자 데이터를 가져옵니다.
        Bundle bundle = getArguments();
        if (bundle != null) {
            user = (User) bundle.getSerializable("user");
            ImageView imgviewMAvt = view.findViewById(R.id.imageViewMyAvt);
            // 사용자 및 아바타 경로가 null이 아니거나 비어 있지 않은 경우 Picasso를 사용하여 이미지를 표시합니다.
            if (user != null && user.getAvatarImage() != null && !user.getAvatarImage().isEmpty()) {
                Picasso.get().load(user.getAvatarImage())
                        .transform(new CircleTransform())
                        .placeholder(R.drawable.custom_border2)
                        .error(R.drawable.custom_border2)
                        .into(imgviewMAvt);
            } else {
                // 이미지 경로가 없거나 비어 있으면 drawable 폴더에서 기본 이미지를 표시합니다.
                imgviewMAvt.setImageResource(R.drawable.user_icon2);
            }
        }

        // 레이아웃을 클릭하여 AddPostActivity로 이동하는 이벤트를 처리합니다.
        RelativeLayout topRelativeLayout = view.findViewById(R.id.topRelativeLayout);
        topRelativeLayout.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), AddPostActivity.class);
            User user = (User) bundle.getSerializable("user");
            intent.putExtra("user", user);
            startActivity(intent);
        });

        // RecyclerView 및 어댑터를 초기화하고 설정합니다.
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        postList = new ArrayList<>();
        adapter = new adapterPostMenu2(getActivity(), postList, this, user);
        recyclerView.setAdapter(adapter);

        // 서버에서 게시물을 가져오는 메서드 호출
        retrievePostsFromServer();

        return view;
    }

    // Fragment가 다시 표시될 때 호출됩니다.
    public void onResume() {
        super.onResume();
        // Fragment가 재개될 때 게시물 목록을 새로 고칩니다.
        retrievePostsFromServer();
    }

    @Override
    public void onDeletePost(int postId, int position) {
        // 게시물 삭제 이벤트 처리
        deletePost(postId, position);
    }

    // 서버에서 게시물을 가져오는 메서드
    private void retrievePostsFromServer() {
        // 사용자 ID 가져오기. 사용자가 null이 아니면 사용자 ID를 가져오고, 그렇지 않으면 -1을 가져옵니다.
        int userId = (user != null) ? user.getUserId() : -1;
        // API 서비스에서 사용자의 모든 게시물을 가져오는 호출 만들기
        Call<List<Post>> call = apiService.getAllPost(userId);
        // 비동기적으로 호출하고 응답 처리
        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                if (response.isSuccessful()) {
                    // 응답이 성공하면 게시물 목록 업데이트 및 어댑터에 알리기
                    List<Post> posts = response.body();
                    updateIsLiked(posts);
                    postList.clear();
                    postList.addAll(posts);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                // 오류 처리

            }
        });
    }

    @Override
    public void onPostClick(int position) {
        // 게시물 클릭 이벤트 처리
        Post clickedPost = postList.get(position);
        int postId = clickedPost.getPostId();
        Intent intent = new Intent(getActivity(), PostDetail.class);
        intent.putExtra("POST_DETAIL", clickedPost);
        intent.putExtra("POST_ID", postId);
        intent.putExtra("user", user);
        startActivity(intent);
    }

    @Override
    public void onCommentClick(int position) {
        // 댓글 버튼 클릭 이벤트 처리
        Post clickedPost = postList.get(position);
        int postId = clickedPost.getPostId();
        Intent intent = new Intent(getActivity(), PostDetail.class);
        intent.putExtra("POST_DETAIL", clickedPost);
        intent.putExtra("POST_ID", postId);
        intent.putExtra("SCROLL_TO_COMMENT", true);
        intent.putExtra("user", user);
        startActivity(intent);
    }

    // 게시물의 좋아요 상태를 업데이트합니다.
    private void updateIsLiked(List<Post> serverPosts) {
        for (Post serverPost : serverPosts) {
            for (Post localPost : postList) {
                if (serverPost.getPostId() == localPost.getPostId()) {
                    // 로컬 게시물의 좋아요 상태를 서버 게시물과 일치하도록 업데이트합니다.
                    localPost.setIsLiked(serverPost.getIsLiked());
                    break;
                }
            }
        }
    }

    // 어댑터에서 좋아요 버튼을 클릭하는 이벤트 처리
    public void likePost(int userId, int postId) {
        if (userId != -1) {
            LikeRequest likeRequest = new LikeRequest(userId, postId);
            Call<Void> call = apiService.likePost(likeRequest);
            call.enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    if (response.isSuccessful()) {
                        // 요청이 성공하면 게시물 목록을 새로 고칩니다.
                        retrievePostsFromServer();
                        adapter.notifyDataSetChanged();
                    }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    // 오류 처리

                }
            });
        }
    }

    // 삭제 버튼을 클릭하는 이벤트 처리
    private void deletePost(int postId, int position) {
        // 게시물 삭제 확인 대화 상자 생성
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Delete Post")
                .setMessage("Are you sure you want to delete this post?")
                .setPositiveButton("OK", (dialog, which) -> performDeletePost(postId, position))
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    // 서버에서 게시물을 삭제하는 메서드
    private void performDeletePost(int postId, int position) {
        // 서버에서 게시물을 삭제하는 호출 만들기
        Call<Void> call = apiService.deletePost(postId);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    // 삭제가 성공하면 성공 메시지를 표시하고 목록에서 게시물을 제거합니다.
                    Toast.makeText(getActivity(), "Post deleted", Toast.LENGTH_SHORT).show();
                    postList.remove(position);
                    adapter.notifyItemRemoved(position);
                } else {
                    // 삭제가 실패한 경우 다른 시나리오 처리 (예: 게시물을 찾을 수 없음, 삭제 실패)
                    if (response.code() == 404) {
                        Toast.makeText(getActivity(), "Post " + postId + " not found", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), "Failed to delete post", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                // 네트워크 오류 처리
                Toast.makeText(getActivity(), "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
