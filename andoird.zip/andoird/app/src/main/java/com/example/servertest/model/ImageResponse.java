package com.example.servertest.model;

import java.util.List;

public class ImageResponse {
    private List<String> advertisement;

    public List<String> getAdvertisement() {
        return advertisement;
    }

    public void setAdvertisement(List<String> advertisement) {
        this.advertisement = advertisement;
    }
}
