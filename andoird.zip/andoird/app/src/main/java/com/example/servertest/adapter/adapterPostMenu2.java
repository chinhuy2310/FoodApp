package com.example.servertest.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servertest.R;
import com.example.servertest.model.Post;
import com.example.servertest.model.User;
import com.squareup.picasso.Picasso;

import java.util.List;

// Adapter class for a RecyclerView displaying a list of posts with menu options
public class adapterPostMenu2 extends RecyclerView.Adapter<adapterPostMenu2.ViewHolder> {
    // List of posts to display
    private List<Post> posts;
    // Context in which the adapter is used
    private Context context;
    // Listener interface to handle click events on posts
    private OnPostClickListener onPostClickListener;
    // User object representing the current user
    private User user;

    // Interface to handle various post-related click events
    public interface OnPostClickListener {
        void onPostClick(int position);
        void onCommentClick(int position);
        void likePost(int userId, int postId);
        void onDeletePost(int postId, int position);
    }

    // Constructor for the adapter
    public adapterPostMenu2(Context context, List<Post> posts, OnPostClickListener listener, User user) {
        this.context = context;
        this.posts = posts;
        this.onPostClickListener = listener;
        this.user = user;
    }

    // Inflate the layout for each item and create a ViewHolder
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.post, parent, false);
        return new ViewHolder(view);
    }

    // Bind the data to the views for each item
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        // Get the current post
        Post post = posts.get(position);

        // Set the post data to the views
        holder.textViewUsername.setText(post.getUsername());
        holder.textViewDateTime.setText(post.getDate());
        holder.textViewTitle.setText(post.getTitle());
        holder.buttonLike.setTag(post.getPostId());
        int isLiked = post.getIsLiked();
        int isRecipe = post.getIsRecipe();

        // Set the like button image based on whether the post is liked
        holder.buttonLike.setImageResource(isLiked == 1 ? R.drawable.ic_liked : R.drawable.like);
        holder.buttonLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onPostClickListener != null) {
                    int userId = user.getUserId();
                    int postId = post.getPostId();
                    onPostClickListener.likePost(userId, postId);
                    notifyDataSetChanged(); // Refresh the item after like action
                }
            }
        });

        // Handle the post options menu click
        holder.postOptions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create a PopupMenu
                PopupMenu popupMenu = new PopupMenu(context, holder.postOptions);
                popupMenu.inflate(R.menu.post_options_menu); // Inflate the menu resource

                // Handle menu item click events
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.menu_report:
                                // Handle the Report action
                                Toast.makeText(context, "Reported", Toast.LENGTH_SHORT).show();
                                return true;
                            case R.id.menu_delete:
                                // Handle the Delete action
                                if (post.getId() == user.getUserId() || user.getIsAdmin() == 1) {
                                    // thực hiện phương thức xóa trong activity
                                    onPostClickListener.onDeletePost(post.getPostId(), position);
                                } else {
                                    Toast.makeText(context, "You do not have permission to delete this post", Toast.LENGTH_SHORT).show();
                                }
                                return true;
                            default:
                                return false;
                        }
                    }
                });

                // Show the PopupMenu
                popupMenu.show();
            }
        });

        // Set the visibility of the recipe text
        holder.txtRecipe.setVisibility(isRecipe == 1 ? View.VISIBLE : View.GONE);

        // Set the like and comment counts
        int likeCount = post.getLikeCount();
        int commentCount = post.getCommentCount();
        holder.likeCountTextView.setText(String.valueOf(likeCount));
        holder.commentCountTextView.setText(String.valueOf(commentCount));

        // Load the avatar image using Picasso
        if (!post.getAvatarUrl().isEmpty()) {
            Picasso.get().load(post.getAvatarUrl()).into(holder.imageViewAvatar);
        } else {
            // Load a default image if the avatar URL is empty
            Picasso.get().load(R.drawable.user_icon2).into(holder.imageViewAvatar);
        }

        // Initialize variable for the first image URL
        String firstImageUrl = null;
        // Check if the image URLs are provided as a string
        if (post.getImageUrls() instanceof String) {
            // If it's a string, split it to get individual URLs
            String imageUrlsString = (String) post.getImageUrls();
            String[] imageUrlArray = imageUrlsString.split(",");
            // Get the first URL from the array
            if (imageUrlArray.length > 0) {
                firstImageUrl = imageUrlArray[0];
            }
        }

        // Load the post image using Picasso if the URL is available, else hide the ImageView
        if (firstImageUrl != null && !firstImageUrl.isEmpty()) {
            Picasso.get().load(firstImageUrl).into(holder.imageViewPost);
            holder.imageViewPost.setVisibility(View.VISIBLE);
        } else {
            holder.imageViewPost.setVisibility(View.GONE);
        }

        // Set the click listener for the entire item
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onPostClickListener != null) {
                    onPostClickListener.onPostClick(position); // Call the interface method
                }
            }
        });

        // Set the click listener for the comment button
        holder.buttonComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onPostClickListener.onCommentClick(position);
            }
        });
    }

    // Return the number of posts
    @Override
    public int getItemCount() {
        return posts.size();
    }

    // ViewHolder class to hold the views for each post item
    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageButton buttonLike, buttonComment, buttonShare;
        TextView textViewUsername, textViewDateTime, textViewTitle, txtRecipe, likeCountTextView, commentCountTextView;
        ImageView imageViewPost, postOptions, imageViewAvatar;

        // Constructor for ViewHolder, initializing the views
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewAvatar = itemView.findViewById(R.id.imageViewAvatar);
            textViewUsername = itemView.findViewById(R.id.textViewUsername);
            textViewDateTime = itemView.findViewById(R.id.textViewDateTime);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            imageViewPost = itemView.findViewById(R.id.imageViewPost);
            txtRecipe = itemView.findViewById(R.id.txtRecipe);
            postOptions = itemView.findViewById(R.id.postoptions);
            likeCountTextView = itemView.findViewById(R.id.likeCountTextView);
            commentCountTextView = itemView.findViewById(R.id.commentCountTextView);
            buttonLike = itemView.findViewById(R.id.buttonLike);
            buttonComment = itemView.findViewById(R.id.buttonComment);
        }
    }
}
