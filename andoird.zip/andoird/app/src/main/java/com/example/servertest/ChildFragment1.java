package com.example.servertest;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servertest.adapter.adapterPostMenu2;
import com.example.servertest.model.Post;
import com.example.servertest.model.User;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChildFragment1 extends Fragment implements adapterPostMenu2.OnPostClickListener {
    // Declare class variables
    private RecyclerView recyclerView; // RecyclerView to display posts
    private adapterPostMenu2 adapter; // Adapter for the RecyclerView
    private List<Post> postList; // List to hold posts
    private User user; // User object
    private APIService apiService; // Service to communicate with the server

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.childfragment, container, false);

        // Initialize the APIService using RetrofitClientInstance
        apiService = RetrofitClientInstance.getRetrofitInstance().create(APIService.class);

        // Retrieve user data from the bundle
        Bundle bundle = getArguments();
        if (bundle != null) {
            user = (User) bundle.getSerializable("user");
            Log.e("child1","userid : "+user.getUserId());
        }else{
            Log.e("err child1","user null");
        }
        // Initialize and setup RecyclerView and Adapter
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        postList = new ArrayList<>();
        // Initialize the adapter with the activity, post list, click listener, and user object
        adapter = new adapterPostMenu2(getActivity(), postList, this, user); // Set listener
        recyclerView.setAdapter(adapter);

        // Call method to retrieve posts from the server
        retrievePostsFromServer();

        return view;
    }

    // Called when the Fragment is visible again
    public void onResume() {
        super.onResume();
        // Refresh the list of posts when the fragment is resumed
        retrievePostsFromServer();
    }

    // Handle click event on the delete button in the Adapter
    @Override
    public void onDeletePost(int postId, int position) {
        // Call method to delete the post
        deletePost(postId, position);
    }

    // Method to send request to get posts from the server
    private void retrievePostsFromServer() {
        // Get the user ID, or -1 if the user is null
        int userId = (user != null) ? user.getUserId() : -1;
        // Create a call to retrieve all posts for the user from the API service
        Call<List<Post>> call = apiService.getMyPosts(userId);
        // Asynchronously enqueue the call and handle the response
        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                if (response.isSuccessful()) {
                    // If the response is successful, update the post list and notify the adapter
                    List<Post> posts = response.body();
                    updateIsLiked(posts);
                    postList.clear();
                    postList.addAll(posts);
                    adapter.notifyDataSetChanged();
                } else {
                    // If the response is not successful:

                }
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                // If the request fails:

            }
        });
    }

    // Handle click event on a post in the Adapter
    @Override
    public void onPostClick(int position) {
        // Get the clicked post and its ID
        Post clickedPost = postList.get(position);
        int postId = clickedPost.getPostId();
        // Create an intent to navigate to PostDetailActivity and pass the post details
        Intent intent = new Intent(getActivity(), PostDetail.class);
        intent.putExtra("POST_DETAIL", clickedPost);
        intent.putExtra("POST_ID", postId);
        intent.putExtra("user", user);
        startActivity(intent);
    }
    // Method to handle click event on the comment button in the Adapter
    @Override
    public void onCommentClick(int position) {
        // Get the post object at the clicked position
        Post clickedPost = postList.get(position);
        int postId = clickedPost.getPostId();
        // Create an intent to navigate to PostDetailActivity, pass the post details, and indicate scrolling to the comment section
        Intent intent = new Intent(getActivity(), PostDetail.class);
        intent.putExtra("POST_DETAIL", clickedPost);
        intent.putExtra("POST_ID", postId);
        intent.putExtra("SCROLL_TO_COMMENT", true); // Send flag to indicate scrolling to the comment section
        intent.putExtra("user", user);
        startActivity(intent);
    }

    // Update the Like status for posts
    private void updateIsLiked(List<Post> serverPosts) {
        for (Post serverPost : serverPosts) {
            for (Post localPost : postList) {
                if (serverPost.getPostId() == localPost.getPostId()) {
                    // Update the like status of the local post to match the server post
                    localPost.setIsLiked(serverPost.getIsLiked());
                    break;
                }
            }
        }
    }

    // Method to handle click event on the Like button in the Adapter
    public void likePost(int userId, int postId)  {
        // Check if the user ID is valid
        if (userId != -1) {
            // Create a LikeRequest object
            LikeRequest likeRequest = new LikeRequest(userId, postId);
            // Send a request to like the post to the server
            Call<Void> call = apiService.likePost(likeRequest);
            call.enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    if (response.isSuccessful()) {
                        // If the request is successful, refresh the list of posts
                        retrievePostsFromServer();
                        adapter.notifyDataSetChanged();
                    } else {
                        // If the request is not successful, log an error message
//                        Log.e("like","response : " + response.message());
                    }
                }
                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    // Handle connection error
                }
            });
        } else {
            // Handle case when userId is not found
        }
    }

    // Method to handle click event on the delete button
    private void deletePost(int postId, int position) {
        // Create a confirmation dialog for post deletion
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Delete Post")
                .setMessage("Are you sure you want to delete this post?")
                .setPositiveButton("OK", (dialog, which) -> {
                    // If the user confirms, delete the post
                    performDeletePost(postId, position);
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    // If the user cancels, dismiss the dialog
                    dialog.dismiss();
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    // Method to perform post deletion on the server
    private void performDeletePost(int postId, int position) {
        // Create a call to delete the post from the server
        Call<Void> call = apiService.deletePost(postId);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    // If the deletion is successful, display a success message, remove the post from the list, and notify the adapter
                    Toast.makeText(getActivity(), "Post deleted", Toast.LENGTH_SHORT).show();
                    postList.remove(position);
                    adapter.notifyItemRemoved(position);
                } else {
                    // If the deletion is not successful, handle different scenarios (e.g., post not found, failed to delete)
                    if (response.code() == 404) {
                        Toast.makeText(getActivity(), "Post "+ postId+" not found", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), "Failed to delete post", Toast.LENGTH_SHORT).show();
//                        Log.e("response","err: " + response.message());
                    }
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                // If the request fails due to network error, display a network error message
                Toast.makeText(getActivity(), "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}