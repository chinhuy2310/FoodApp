package com.example.servertest.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servertest.PostDetail;
import com.example.servertest.R;
import com.example.servertest.model.CircleTransform;
import com.example.servertest.model.Comment;
import com.example.servertest.model.Post;
import com.example.servertest.model.User;
import com.squareup.picasso.Picasso;

import java.util.List;

// Adapter class for a RecyclerView displaying a list of comments
public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.CommentViewHolder> {

    private Context context;
    private List<Comment> commentList;
    private User user;
    private Post post;

    // Constructor for the adapter
    public CommentAdapter(Context context, List<Comment> commentList, Post post) {
        this.context = context;
        this.commentList = commentList;
        this.post = post;
    }

    // Method to set the current user
    public void setUser(User user) {
        this.user = user;
    }

    // Inflate the layout for each item and create a ViewHolder
    @NonNull
    @Override
    public CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.comment, parent, false);
        return new CommentViewHolder(view);
    }

    // Bind the data to the views for each item
    @Override
    public void onBindViewHolder(@NonNull CommentViewHolder holder, @SuppressLint("RecyclerView") int position) {
        // Get the current comment
        Comment comment = commentList.get(position);

        // Set the comment data to the views
        holder.textViewUsername.setText(comment.getUsername());
        holder.textViewContent.setText(comment.getContent());

        // Load the avatar image using Picasso, with a circular transformation
        if (!comment.getAvatarUrl().isEmpty()) {
            Picasso.get().load(comment.getAvatarUrl())
                    .transform(new CircleTransform())
                    .into(holder.imageViewCommenterAvatar);
        } else {
            // Load a default image if the avatar URL is empty
            Picasso.get().load(R.drawable.user_icon2).into(holder.imageViewCommenterAvatar);
        }

        // Handle the post options menu click
        holder.postOptions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create a PopupMenu
                PopupMenu popupMenu = new PopupMenu(context, holder.postOptions);
                popupMenu.inflate(R.menu.post_options_menu); // Inflate the menu resource

                // Handle menu item click events
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.menu_report:
                                // Handle the Report action
                                Toast.makeText(context, "Reported", Toast.LENGTH_SHORT).show();
                                return true;
                            case R.id.menu_delete:
                                // Check if the user has permission to delete the comment
                                if (comment.getUser_id() == user.getUserId() ||
                                        (comment.getPost_id() == post.getPostId() && post.getId() == user.getUserId())) {
                                    // Get the ID of the comment to be deleted
                                    int commentId = commentList.get(position).getComment_id();
                                    // Call the method to delete the comment from the activity
                                    ((PostDetail) context).deleteCommentConfirmation(commentId);
                                } else {
                                    Toast.makeText(context, "You do not have permission to delete this comment", Toast.LENGTH_SHORT).show();
                                }
                                return true;
                            default:
                                return false;
                        }
                    }
                });

                // Show the PopupMenu
                popupMenu.show();
            }
        });
    }

    // Return the number of comments
    @Override
    public int getItemCount() {
        return commentList.size();
    }

    // ViewHolder class to hold the views for each comment item
    public class CommentViewHolder extends RecyclerView.ViewHolder {
        ImageView imageViewCommenterAvatar, postOptions;
        TextView textViewUsername, textViewContent;

        // Constructor for ViewHolder, initializing the views
        public CommentViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewCommenterAvatar = itemView.findViewById(R.id.imageViewCommentAvatar);
            textViewUsername = itemView.findViewById(R.id.textViewUsername);
            textViewContent = itemView.findViewById(R.id.textViewComments);
            postOptions = itemView.findViewById(R.id.postoptions);
        }
    }
}
