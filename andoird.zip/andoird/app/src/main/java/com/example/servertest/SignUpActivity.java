package com.example.servertest;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpActivity extends AppCompatActivity {
    private EditText usernameEditText, accnameEditText, passwordEditText, emailEditText, confirmPasswordEditText;
    private ImageView eyeIcon1, eyeIcon2;
    private TextView loginTextView, signUpButton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);
        // 레이아웃에서 뷰들을 찾아와 연결합니다
        usernameEditText = findViewById(R.id.createUsername);
        accnameEditText = findViewById(R.id.createAccname);
        passwordEditText = findViewById(R.id.createPW);
        confirmPasswordEditText = findViewById(R.id.createPW2);
        emailEditText = findViewById(R.id.createEmail);
        signUpButton = findViewById(R.id.SignUpbutton);
        loginTextView = findViewById(R.id.logintext);
        eyeIcon1 = findViewById(R.id.eye_icon1);
        eyeIcon2 = findViewById(R.id.eye_icon2);

        // 로그인 텍스트를 클릭할 때 로그인으로 이동
        loginTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // SignUpActivity에서 LoginActivity로 전환하기 위해 인텐트 생성
                Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // LoginActivity로 전환한 후 SignUpActivity 닫기
            }
        });

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        final APIService apiService = RetrofitClientInstance.getRetrofitInstance().create(APIService.class);

        // 가입 버튼 클릭 시 이벤트 처리
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String useraccname = accnameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                String confirmPassword = confirmPasswordEditText.getText().toString();
                String email = emailEditText.getText().toString();
                if (username.isEmpty() || useraccname.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || email.isEmpty()) {
                    Toast.makeText(SignUpActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!password.equals(confirmPassword)) {  // 비밀번호 확인
                    Toast.makeText(SignUpActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }
                // 데이터 유효성 검사 및 새 가입 요청 생성
                SignupRequest signupRequest = new SignupRequest(username, useraccname, password, email);

                Call<Void> call = apiService.signup(signupRequest);  // 새 사용자 가입 요청을 서버로 전송
                call.enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if (response.isSuccessful()) {      // 가입 성공
                            Toast.makeText(SignUpActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            if (response.code() == 400) { // 상태 코드가 400 (잘못된 요청) 인 경우 useraccname 중복
                                Toast.makeText(SignUpActivity.this, "Account ID already exists", Toast.LENGTH_SHORT).show();
                            } else {    // 다른 상태 코드인 경우 기본 메시지 표시
                                Toast.makeText(SignUpActivity.this, "Registration failed: " + response.message(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<Void> call, Throwable t) { // 연결 오류 처리
                        Toast.makeText(SignUpActivity.this, "Registration failed : " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        // 비밀번호 입력 시 눈 아이콘 클릭 이벤트 처리
        eyeIcon1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (passwordEditText.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eyeIcon1.setImageResource(R.drawable.ic_eye);
                } else {
                    passwordEditText.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    eyeIcon1.setImageResource(R.drawable.ic_eyex);
                }
            }
        });

        // 비밀번호 확인 입력 시 눈 아이콘 클릭 이벤트 처리
        eyeIcon2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (confirmPasswordEditText.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    confirmPasswordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eyeIcon2.setImageResource(R.drawable.ic_eye);
                } else {
                    confirmPasswordEditText.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    eyeIcon2.setImageResource(R.drawable.ic_eyex);
                }
            }
        });
    }
}
