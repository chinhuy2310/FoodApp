package com.example.servertest;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import android.view.inputmethod.InputMethodManager;

import androidx.viewpager2.widget.ViewPager2;

import com.example.servertest.adapter.ViewPagerAdapter;
import com.example.servertest.model.User;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

// MainActivity class which extends AppCompatActivity
public class MainActivity extends AppCompatActivity {

    // Declare variables
    private ViewPager2 viewPager;
    private TabLayout tabLayout;
    private User loggedInUser;
    private InputMethodManager inputMethodManager;


    // onCreate method called when MainActivity is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Initialize InputMethodManager
        inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        // Hide the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Retrieve user data passed from the login activity
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("user")) {
            loggedInUser = (User) intent.getSerializableExtra("user");
        }

        // Initialize ViewPager2 and TabLayout
        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);

        // Initialize the ViewPagerAdapter
        ViewPagerAdapter adapter = new ViewPagerAdapter(this);

        // Add fragments to the adapter based on whether a user is logged in or not
        if (loggedInUser != null) {
            Bundle bundle = new Bundle();
            bundle.putSerializable("user", loggedInUser);

            Menu1Fragment menu1Fragment = new Menu1Fragment();
            menu1Fragment.setArguments(bundle);
            adapter.addFragment(menu1Fragment);

            Menu2Fragment menu2Fragment = new Menu2Fragment();
            menu2Fragment.setArguments(bundle);
            adapter.addFragment(menu2Fragment);

            Menu3Fragment menu3Fragment = new Menu3Fragment();
            menu3Fragment.setArguments(bundle);
            adapter.addFragment(menu3Fragment);

            adapter.addFragment(new Menu4Fragment());

            Menu5Fragment menu5Fragment = new Menu5Fragment();
            menu5Fragment.setArguments(bundle);
            adapter.addFragment(menu5Fragment);
        } else {
            adapter.addFragment(new Menu1Fragment());
            adapter.addFragment(new Menu2Fragment());
            adapter.addFragment(new Menu3Fragment());
            adapter.addFragment(new Menu4Fragment());
            adapter.addFragment(new Menu5Fragment());
        }

        // Set the adapter to the ViewPager2
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(5);

        // Set tab icons and attach TabLayout with ViewPager2
        int[] tabIcons = {R.drawable.ic_home, R.drawable.bangtin, R.drawable.ic_search, R.drawable.ic_notification, R.drawable.ic_taikhoan};
        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            tab.setIcon(tabIcons[position]); // Set tab icon
        }).attach();

        // Set a listener for tab selection events
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition(), true); // Move to the selected tab
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                // No action needed when tab is unselected
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // No action needed when tab is reselected
            }
        });
    }

    // Method to switch to Menu3Fragment and fetch data based on group ID
    public void switchToMenu3Fragment(int groupId) {
        ViewPagerAdapter adapter = (ViewPagerAdapter) viewPager.getAdapter();
        Menu3Fragment menu3Fragment = (Menu3Fragment) adapter.createFragment(2);

        // Perform the Fragment transition
        if (menu3Fragment != null) {
            menu3Fragment.fetchDataFromApi(groupId, ""); // Fetch data from API
            viewPager.setCurrentItem(2, true); // Move to Menu3Fragment
        }
    }

}
