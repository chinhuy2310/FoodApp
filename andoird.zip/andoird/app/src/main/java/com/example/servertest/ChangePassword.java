package com.example.servertest;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.example.servertest.model.User;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class ChangePassword extends AppCompatActivity {

    private EditText oldPassword, newPassword, confirmNewPassword;
    private Button confirmButton;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_password);

        // Ánh xạ các thành phần từ layout
        oldPassword = findViewById(R.id.password);
        newPassword = findViewById(R.id.editPW);
        confirmNewPassword = findViewById(R.id.editPW2);
        confirmButton = findViewById(R.id.send);

        // Lấy thông tin người dùng từ Intent
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            user = (User) bundle.getSerializable("user");
        }

        // Xử lý sự kiện khi nhấn nút xác nhận
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String password = oldPassword.getText().toString();
                String newpassword = newPassword.getText().toString();
                String confirmPW = confirmNewPassword.getText().toString();

                // Kiểm tra xem mật khẩu mới và mật khẩu xác nhận có khớp nhau không
                if (!newpassword.equals(confirmPW)) {
                    Toast.makeText(ChangePassword.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Tạo yêu cầu cập nhật mật khẩu
                PasswordUpdateRequest request = new PasswordUpdateRequest(password, newpassword);
                // Thực hiện tác vụ cập nhật mật khẩu
                new UpdatePasswordTask().execute(request);
            }
        });

        // Thiết lập nút back trên ActionBar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Xử lý sự kiện khi nhấn nút back trên ActionBar
        if (item.getItemId() == android.R.id.home) {
            finish(); // Quay về activity trước đó
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Lớp AsyncTask để thực hiện tác vụ cập nhật mật khẩu
    private class UpdatePasswordTask extends AsyncTask<PasswordUpdateRequest, Void, Boolean> {
        @Override
        protected Boolean doInBackground(PasswordUpdateRequest... params) {
            PasswordUpdateRequest request = params[0];

            try {
                // Tạo và gửi yêu cầu cập nhật mật khẩu đến API
                APIService apiService = RetrofitClientInstance.getRetrofitInstance().create(APIService.class);
                int userId = user.getUserId();
                Call<ResponseBody> call = apiService.updatePassword(userId, request);

                // Nhận và xử lý phản hồi từ API
                Response<ResponseBody> response = call.execute();
                finish();
                return response.isSuccessful();

            } catch (Exception e) {
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            // Hiển thị thông báo kết quả sau khi tác vụ hoàn thành
            if (success) {
                Toast.makeText(ChangePassword.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(ChangePassword.this, "Failed to update password", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
