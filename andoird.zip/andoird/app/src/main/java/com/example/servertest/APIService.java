package com.example.servertest;
import com.example.servertest.model.Comment;
import com.example.servertest.model.ImageResponse;
import com.example.servertest.model.Post;
import com.example.servertest.model.User;
import com.example.servertest.model.UserResponse;



import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;


public interface APIService {

    // các annotation @GET và @POST được sử dụng để chỉ định
    // loại yêu cầu HTTP tương ứng với từng phương thức API.

    @POST("login")
    Call<User> login(@Body LoginRequest loginRequest);

    @GET("user/{account}")
    Call<UserResponse> getUser(@Path("account") String useraccname);

    @POST("signup")
    Call<Void> signup(@Body SignupRequest signupRequest);

    @GET("popularposts")
    Call<List<Post>> getPopularPosts(@Query("user_id") int userId);

    @GET("allposts")
    Call<List<Post>> getAllPost(@Query("user_id") int userId);

    @GET("myposts")
    Call<List<Post>> getMyPosts(@Query("user_id") int userId);

    @GET("likedposts")
    Call<List<Post>> getLikedPosts(@Query("user_id") int userId);

    @POST("likepost")
    Call<Void> likePost(@Body LikeRequest likeRequest);

    @DELETE("deleteposts/{postId}")
    Call<Void> deletePost(@Path("postId") int postId);

    @DELETE("deletecomments/{commentId}")
    Call<Void> deleteComment(@Path("commentId") int commentId);

    @GET("advertisements")
    Call<ImageResponse> getImageUrls();


    @Multipart
    @POST("/createposts")
    Call<Void> createPostWithImages(
            @Part("post_title") RequestBody postTitle,
            @Part("post_content") RequestBody postContent,
            @Part("isRecipe") RequestBody isRecipe,
            @Part("user_id") RequestBody userId,
            @Part("post_group") RequestBody postGroup,
            @Part List<MultipartBody.Part> images
    );

    @GET("post/{post_id}")
    Call<Post> getPost(@Query("post_id") int postId,@Query("user_id") int userId);

    @GET("/comments/{post_id}")
    Call<List<Comment>> getComments(@Path("post_id") int postId);

    @POST("/addcomment")
    Call<Void> addComment(@Body CommentData commentData);

    @GET("/search")
    Call<List<Post>> getSearch(@Query("groupId") int groupId, @Query("searchText") String searchText);

    @Multipart
    @POST("update_user/{userId}")
    Call<ResponseBody> updateUserWithImage(
            @Path("userId") int userId,
            @Part("name") RequestBody username,
            @Part("email") RequestBody email,
            @Part MultipartBody.Part avatarImage
    );
    @POST("/update_userpw/{userId}")
    Call<ResponseBody> updatePassword( @Path("userId") int userId, @Body PasswordUpdateRequest request);

}

//Các lớp PasswordUpdateRequest, CommentData,
// và LikeRequest,... được sử dụng để đóng gói dữ liệu cho các yêu cầu API tương ứng

class PasswordUpdateRequest {
    private String oldPassword;
    private String newPassword;

    public PasswordUpdateRequest(String oldPassword, String newPassword) {
        this.oldPassword = oldPassword;
        this.newPassword = newPassword;
    }
}

class CommentData {
    private int userId;
    private int postId;
    private String commentContent;

    public CommentData(int userId, int postId, String commentContent) {
        this.userId = userId;
        this.postId = postId;
        this.commentContent = commentContent;
    }
}

class LikeRequest {
    private int userId;
    private int postId;

    public LikeRequest(int userId, int postId) {
        this.userId = userId;
        this.postId = postId;
    }
}
class LoginRequest {
    private String account;
    private String password;

    public LoginRequest(String account, String password) {
        this.account = account;
        this.password = password;
    }
}
class SignupRequest {
    private String name;
    private String account;
    private String password;
    private String email;

    public SignupRequest(String name, String account, String password, String email){
        this.name = name;
        this.account = account;
        this.password = password;
        this.email = email;
    }
}