package com.example.servertest.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servertest.R;
import com.example.servertest.model.Post;
import com.squareup.picasso.Picasso;

import java.util.List;

// Adapter class for a RecyclerView displaying a list of posts
public class adapterPostMenu1 extends RecyclerView.Adapter<adapterPostMenu1.ViewHolder> {
    // List of posts to display
    private List<Post> postList;
    // Context in which the adapter is used
    private Context context;
    // Listener interface to handle click events on posts
    private OnPostClickListener onPostClickListener;

    // Interface to handle post click events
    public interface OnPostClickListener {
        void onPostClick(int position);
    }

    // Constructor for the adapter
    public adapterPostMenu1(Context context, List<Post> postList, OnPostClickListener listener) {
        this.context = context;
        this.postList = postList;
        this.onPostClickListener = listener;
    }

    // ViewHolder class to hold the views for each post item
    public static class ViewHolder extends RecyclerView.ViewHolder {
        // ImageView to display the post image
        public ImageView imageView;
        // TextView to display the post title
        public TextView textViewTitle;

        // Constructor for ViewHolder, initializing the views
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imgNewTruyen);
            textViewTitle = itemView.findViewById(R.id.textviewTenTruyen);
        }
    }

    // Inflate the layout for each item and create a ViewHolder
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.most_popular_post, parent, false);
        return new ViewHolder(view);
    }

    // Bind the data to the views for each item
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        // Get the current post
        Post post = postList.get(position);

        // Initialize variable for the first image URL
        String firstImageUrl = null;
        // Check if the image URLs are provided as a string
        if (post.getImageUrls() instanceof String) {
            // If it's a string, split it to get individual URLs
            String imageUrlsString = (String) post.getImageUrls();
            String[] imageUrlArray = imageUrlsString.split(",");
            // Get the first URL from the array
            if (imageUrlArray.length > 0) {
                firstImageUrl = imageUrlArray[0];
            }
        }

        // Load the image using Picasso if the URL is available, else set a default image
        if (firstImageUrl != null && !firstImageUrl.isEmpty()) {
            Picasso.get().load(firstImageUrl).into(holder.imageView);
        } else {
            holder.imageView.setImageResource(R.drawable.food_bg);
        }

        // Set the post title
        holder.textViewTitle.setText(post.getTitle());

        // Handle click event on the image
        holder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onPostClickListener != null) {
                    onPostClickListener.onPostClick(position);
                }
            }
        });
    }

    // Return the number of posts
    @Override
    public int getItemCount() {
        return postList.size();
    }
}
