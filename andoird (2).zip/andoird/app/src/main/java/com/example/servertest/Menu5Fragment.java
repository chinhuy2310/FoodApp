package com.example.servertest;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.example.servertest.adapter.ViewPagerAdapter;
import com.example.servertest.model.CircleTransform;
import com.example.servertest.model.User;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.squareup.picasso.Picasso;
public class Menu5Fragment extends Fragment {

    private DrawerLayout drawerLayout;
    private ImageView openMenuButton;
    private User user;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.menu5fragment, container, false);



        NavigationView navigationView = view.findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                // Xử lý sự kiện khi một mục menu được chọn
                switch (item.getItemId()) {
                    case R.id.editinformation:
                        // Xử lý khi menu item 1 được chọn
                        // chuyển đến trang chỉnh sửa thôn tin cá nhân
                        Intent intent = new Intent(getActivity(), UpdateInfo.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("user", user);
                        intent.putExtras(bundle);
                        startActivity(intent);
                        return true;
                    case R.id.editPw:
                        intent = new Intent(getActivity(), ChangePassword.class);
                        Bundle pwBundle = new Bundle();
                        pwBundle.putSerializable("user", user);
                        intent.putExtras(pwBundle);
                        startActivity(intent);
                        return true;
                    case R.id.textViewLogout:
                        // Xử lý khi menu item 3 được chọn
                        // đăng xuất và chuyển đến trang login
                        intent = new Intent(getActivity(), LoginActivity.class);
                        startActivity(intent);
                        getActivity().finish();
                        return true;
                    default:
                        return false;
                }
            }
        });



        drawerLayout = view.findViewById(R.id.drawer_layout);
        openMenuButton = view.findViewById(R.id.button_open_menu);

        openMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
            }
        });

        Bundle bundle = getArguments();
        if (bundle != null) {
            user = (User) bundle.getSerializable("user");
            if (user != null) {
                TextView usernameTextView = view.findViewById(R.id.Text_Name);
                TextView emailTextView = view.findViewById(R.id.text_gmail);
                ImageView imgviewMyAvt = view.findViewById(R.id.imageViewMyAvt);
                usernameTextView.setText(user.getUsername());
                emailTextView.setText(user.getEmail());
                if (user != null && user.getAvatarImage() != null && !user.getAvatarImage().isEmpty()) {
                    Picasso.get().load(user.getAvatarImage())
                            .transform(new CircleTransform())
                            .placeholder(R.drawable.custom_border2)
                            .error(R.drawable.custom_border2)
                            .into(imgviewMyAvt);
                } else {
                    // Nếu không có đường dẫn ảnh hoặc đường dẫn rỗng, hiển thị ảnh mặc định từ thư mục drawable
                    // 이미지 경로가 없거나 경로가 비어 있는 경우 drawable 폴더의 기본 이미지를 표시합니다.
                    imgviewMyAvt.setImageResource(R.drawable.user_icon2);
                }

            }
        }



        ViewPager2 viewPager2 = view.findViewById(R.id.viewPager2);
        TabLayout tabLayout = view.findViewById(R.id.tabLayout);

        // Tạo adapter cho ViewPager2
        ViewPagerAdapter adapter = new ViewPagerAdapter((AppCompatActivity) getActivity());

        // Thêm các fragment con vào adapter

        ChildFragment1 fragment1 = new ChildFragment1();
        fragment1.setArguments(bundle);
        adapter.addFragment(fragment1);
        ChildFragment2 fragment2 = new ChildFragment2();
        fragment2.setArguments(bundle);
        adapter.addFragment(fragment2);

        // Thiết lập adapter cho ViewPager2
        viewPager2.setAdapter(adapter);

        // Liên kết TabLayout với ViewPager2 và thiết lập icon cho các tab
        new TabLayoutMediator(tabLayout, viewPager2, (tab, position) -> {
            if (position == 0) {
                tab.setText("My Post");
//                tab.setIcon(R.drawable.ic_delete); // Đặt icon cho tab 1
            } else {
                tab.setText("Liked Post");
//                tab.setIcon(R.drawable.ic_facebookpng); // Đặt icon cho tab 2
            }
        }).attach();


        return view;
    }

    private void openMenu() {
        drawerLayout.openDrawer(GravityCompat.END); // Mở menu từ bên phải
    }

}