package com.example.servertest;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.example.servertest.model.User;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class ChangePassword extends AppCompatActivity {

    private EditText oldPassword, newPassword, confirmNewPassword;
    private Button confirmButton;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_password);

        oldPassword = findViewById(R.id.password);
        newPassword = findViewById(R.id.editPW);
        confirmNewPassword = findViewById(R.id.editPW2);
        confirmButton = findViewById(R.id.send);

        // Retrieve user ID from Intent
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            user = (User) bundle.getSerializable("user");

        }
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String password = oldPassword.getText().toString();
                String newpassword = newPassword.getText().toString();
                String confirmPW = confirmNewPassword.getText().toString();

                if (!newpassword.equals(confirmPW)) {
                    Toast.makeText(ChangePassword.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                PasswordUpdateRequest request = new PasswordUpdateRequest(password, newpassword);
                new UpdatePasswordTask().execute(request);
            }
        });

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Go back to previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private class UpdatePasswordTask extends AsyncTask<PasswordUpdateRequest, Void, Boolean> {
        @Override
        protected Boolean doInBackground(PasswordUpdateRequest... params) {
            PasswordUpdateRequest request = params[0];

            try {
                APIService apiService = RetrofitClientInstance.getRetrofitInstance().create(APIService.class);
                int userId = user.getUserId();
                Call<ResponseBody> call = apiService.updatePassword(userId, request);

                Response<ResponseBody> response = call.execute();
                finish();
                return response.isSuccessful();

            } catch (Exception e) {

                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                Toast.makeText(ChangePassword.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(ChangePassword.this, "Failed to update password", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
